## 使用说明

1. **准备文件**  
   - 将皮肤 PNG 文件（如 `*.png`, `*.tga`,`*.jpg` ）和脚本放在同一文件夹
   - 注意文件格式，仅限png,tga,jpg

2. **运行脚本**  
   ```bash
   chmod +x generate_skin_pack.sh
   ./generate_skin_pack.sh
   ```

3. **根据脚本指引填写**  
   - 皮肤包名称  
   - 每个皮肤的名称  
   - 选择模型类型（1=纤细(Alex)，2=粗壮(Steve)）

4. **获取结果**  
   生成完成后会得到 `.mcpack` 文件

> 注意：  
> - 仅支持 Minecraft 基岩版  
> - 网易版不可用  
> - 需要提前安装 `uuidgen` 和 `zip` 工具(不安装也没事，脚本会自己装的)

作者:Evo_creative
